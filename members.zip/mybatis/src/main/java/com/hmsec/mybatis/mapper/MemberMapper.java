package com.hmsec.mybatis.mapper;

import com.hmsec.mybatis.domain.Member;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface MemberMapper {

	List<Member> select(@Param("limit") int limit);
	List<Member> selectAll();
	Member selectBySeq(@Param("seq") long seq);
	Member selectById(@Param("userId") String userId);
    int insert(@Param("member") Member member);
    int update(@Param("member") Member member);
    int delete(@Param("seq") long seq);
    
}
