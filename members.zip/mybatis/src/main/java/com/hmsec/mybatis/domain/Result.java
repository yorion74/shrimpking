package com.hmsec.mybatis.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@RequiredArgsConstructor
@Getter
@Setter
public class Result {
    private final boolean result; // 성공 여부를 나타내는 변수
    private final String code;
    private final String message;
    private String errMsg; // 시스템에서 발생하는 상세 에러 메시지
    private Object contents;
    
}
