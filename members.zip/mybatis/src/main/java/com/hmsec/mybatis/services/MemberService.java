package com.hmsec.mybatis.services;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import com.hmsec.mybatis.domain.Member;
import com.hmsec.mybatis.domain.Result;
import com.hmsec.mybatis.mapper.MemberMapper;
import com.hmsec.mybatis.util.ResponseUtil;

import java.util.List;


@Slf4j
@Service
public class MemberService {

	@Autowired
   	private MemberMapper memberMapper;	
	@Autowired
	private ResponseUtil responseUtil;	
	
    public List<Member> getMemberList(int limit) {   
        return memberMapper.select(limit);
    }   
    
    public List<Member> getMembers() {   
        return memberMapper.selectAll();
    }   
    
    public Member getMemberbySeq(long seq) {   
        return memberMapper.selectBySeq(seq);
    }   
    public Member getMemberbyId(String userId) {   
        return memberMapper.selectById(userId);
    }    
    
    public Result createMember(Member member) {
  
    	Object[] args = {member.getUserName(),member.getUserId()};
    	Result result = responseUtil.getSuccess("1010",args); //성공

    	try {
        
    		memberMapper.insert(member);
    		
    	}
        catch(DataIntegrityViolationException  ex) {
		    result = responseUtil.getFail("1011",args,ex.getMessage()); // 실패	
        }
    	catch(Exception ex) {
    		result = responseUtil.getFail("9999",args,ex.getMessage()); // 실패
    	} 

    	return result;
        
    }
    
    public int updateMember(Member member) {
        int result = 5;
        try {
            result = memberMapper.update(member);
            log.debug(result + "");
        } catch (Exception e) {
            log.error(e.toString());
        }
        return result;
    }
    public int deleteMember(long seq) {
        int result = 5;
        try {
            result = memberMapper.delete(seq);
            log.debug(result + "");
        } catch (Exception e) {
            log.error(e.toString());
        }
        return result;
    }
}