package com.hmsec.mybatis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hmsec.mybatis.domain.Member;
import com.hmsec.mybatis.services.MemberService;

@Controller
public class MvcController {

	@Autowired
	MemberService memberService;
	
	@GetMapping("/list") //get Method mapping url : index
	public String list(@RequestParam(value="limit", required=false) int limit, ModelMap model) {
		List<Member> memberList = memberService.getMemberList(limit);
		model.addAttribute("lists", memberList);
		return "list";
	}
	
}
