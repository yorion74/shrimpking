package com.hmsec.mybatis.domain;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter

public class Member {

    private Long seq;

    private String userName;

    private String userId;

}

