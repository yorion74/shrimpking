
package com.hmsec.mybatis.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;
import com.hmsec.mybatis.domain.Member;
import com.hmsec.mybatis.domain.Result;
import com.hmsec.mybatis.services.MemberService;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/")
public class MemberController {
	
	//@GetMapping
	//@PostMapping => insert
	//@PutMapping
	//@DeleteMapping
	
	@Autowired
	private MemberService memberService;
	
	@GetMapping("/index")
	public String hi() {
		return "hi";
	}
	
	@GetMapping("/name")
	public String hi1(@RequestParam(name="username") String username) {
		return "hi1=" + username;
	}
	
	@GetMapping("/member/seq")
	public Member hi2(@RequestParam(name="seq") long seq) {		
		return memberService.getMemberbySeq(seq);
		
	}

	@GetMapping("/member/id")
	public Member hi2(@RequestParam(name="userid") String userId) {		
		return memberService.getMemberbyId(userId);
	}
	
	@GetMapping("/member/{seq}")
	public Member hi3(@PathVariable("seq")  long seq) {
		return memberService.getMemberbySeq(seq);
	}
	
	@GetMapping("/members/{limit}")
	public List<Member> memberList(@PathVariable("limit") int limit) {
		return memberService.getMemberList(limit);
	}
	
//	@GetMapping("/member/list")
//	public ResposeEntity<List<Member>> memberListwithlimit(@RequestParam(value="limit", required = false) String limit) {
//		
//		if(limit == null) {
//			
//		} else {
//			return memberService.getMemberList((int)limit);
//		}
//	
//	}
	@GetMapping("/members")
	public List<Member> membersAll() {
		return memberService.getMembers();
	}
	
//	@PostMapping("/member/new")
//	public int ResponseEntity<Member> createMember(@RequestParam(name="userid") String userId, @RequestParam(name="username") String userName) {
//		
//		Member member = new Member();
//	
//		member.setUserId(userId);
//		member.setUserName(userName);
//		
//		return memberService.createMember(member);
//	}
	
	@PostMapping("/member/new") 
	public ResponseEntity<Result> members(@RequestBody Member member) {
		
		Result result = memberService.createMember(member);
		
		result.setContents(member);
		
		if (result.isResult()) {
			return ResponseEntity.status(HttpStatus.CREATED).body(result);
		} else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
		}
		
	}
	
	@PostMapping("/member/update")
	public int updateMember(@RequestParam(name="seq") long seq, @RequestParam(name="userid") String userId, @RequestParam(name="username") String userName) {
		
		Member member = new Member();
	    member.setSeq(seq);
		member.setUserId(userId);
		member.setUserName(userName);
		
		return memberService.updateMember(member);
	}
	@PostMapping("/member/delete")
	public int deleteMember(@RequestParam(name="seq") long seq) {
		
		return memberService.deleteMember(seq);
	}
}