package com.hmsec.mybatis.util;

import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import com.hmsec.mybatis.domain.Result;

import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class ResponseUtil {
	private final MessageSource messageSource;

	public ResponseUtil() {
		this.messageSource = createMessageSource();
	}

    // MessageSource 객체 생성
    private MessageSource createMessageSource() {
        ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
        messageSource.setBasename("messages/messages"); // 실제 메시지 파일 경로
        messageSource.setDefaultEncoding("UTF-8");
        return messageSource;
    }
    
    private Locale getLocale() {
        return LocaleContextHolder.getLocale();
    }
    
    private String getMessage(String code,Object[] args) {
    	
        // 메시지 키를 기반으로 기본 메시지를 가져옴
        String messageKey = "code." + code;
        return messageSource.getMessage(messageKey, args, getLocale());
    }
    
    
    public Result getResultWithErrors(String code, Map<String, String> errors) {

        // 오류 메시지들을 하나의 문자열로 결합
        String errorMessages = errors.entrySet().stream()
            .map(entry -> entry.getKey() + ": " + entry.getValue())
            .collect(Collectors.joining(", "));

        return new Result(false, code, getMessage(code,null), errorMessages, null);
    }

    public Result getSuccess(String code,Object[] args) {

    	return new Result(true, code, getMessage(code,args));
    }
    
    public Result getFail(String code,Object[] args, String errMsg) {

    	return new Result(false, code, getMessage(code,args),errMsg,null);
    }
}
